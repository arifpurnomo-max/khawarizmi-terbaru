 const data = {
    seriInfo: {
      name: "Seri Teknologi Islami"
    },
    books: [
       
    {
      id: "book-1",
      judul: "LC (Licuid Curriculum)",
      seri: "Karya Independen",
      deskripsi: "Tujuan pendidikan dari liquid curriculum adalah mencapai stabilisasi moral, mental, dan produktifitas lebih cepat.Siapapun yang mendambakan lahirnya generasi impian, baik anda adalah seorang guru maupun orang tua, Liquid Curriculum adalah jawabannya. Insyaallah.",
      publishYear: 2025,
      price: {
        normal: 150000,
        discount: 120000
      },
      coverUrl: "img/LC/cover.jpg",
      linkid: "https://gsiofficial.xyz/gsiofficial/rYM9yVK",
      linkshopee: "https://shopee.co.id/Liquid-Curicullum-Kurikulum-untuk-Sekolah-Impian-yang-Akan-Menghasilkan-Generasi-Impian-i.1344216734.28786791996",
    },
    {
      id: "book-2",
      judul: "ISLAMIC TECHNOLOGY MINDSET INSTALLATION (ITMI)",
      seri: "Seri Teknologi Islami",
      deskripsi: "Di buku ini dijabarkan apa itu ITMI secara detail. ITMI adalah bagian dari Liquid Curriculum yang memiliki dua fungsi utama.Fungsi ITMI yang pertama adalah sebagai metode preventif & kuratif untuk mudhorotnya teknologi, seperti nomophobia, narkolema, game addiction, dsb. Fungsi kedua dari ITMI adalah sebagai metode belajar mapel IT yang efektif, lebih cepat, sebab menggunakan strategi ajar yang unik",
      publishYear: 2025,
      price: {
        normal: 130000,
        discount: 104000
      },
      coverUrl: "img/ITMI/cover.jpg",
      linkid: "https://gsiofficial.xyz/gsiofficial/aYgaVW1",
      linkshopee: "https://shopee.co.id/Islamic-Technology-Mindset-Installation-(ITMI)-i.1344216734.40351671301",
    },
    {
      id: "book-3",
      judul: "SEJARAH TEKNOLOGI DARI PERSPEKTIF KAUM MUSLIMIN",
      seri: "Seri Teknologi Islami",
      deskripsi: "Buku ini adalah buku tentang sejarah teknologi yang jujur, di dalam buku ini dijabarkan tentang keterlibatan kaum muslimin dalam mempelopori kebangkitan teknologi.Bagaimana ilmuwan muslim menjaga dan memelihara khazanah keilmuan peradaban-peradaban hebat di masa lalu, seperti Yunani, Persia, bahkan China.Bagaimana ilmuwan muslim meneruskan penelitian mereka dengan berpandu dengan Al-Quran yang hasilnya adalah penemuan-penemuan yang orisinil. Buku ini juga menjelaskan bagaimana peradaban keilmuan itu bisa runtuh dan berpindah ke barat.Semua isi buku ini insya Allah akan membangkitkan semangat dan gairah pemuda muslim untuk kembali bangkit dan kembali mendekati teknolog.",
      publishYear: 2025,
      price: {
        normal: 175000,
        discount: 140000
      },
      coverUrl: "img/ST/cover.jpg",
      linkid: "https://gsiofficial.xyz/gsiofficial/glPZKz9",
      linkshopee: "https://shopee.co.id/Seri-Teknologi-Islami-Sejarah-Teknologi-dari-Perspektif-Kaum-Muslim-i.1344216734.40751654113",
    },
    {
      id: "book-4",
      judul: "MENTAL BELAJAR TEKNOLOGI",
      seri: "Seri Teknologi Islami",
      deskripsi: "Teknologi bagaikan kotak pandora, di dalamnya terdapat keburukan dan manfaat.Menghindari teknologi sudah tak mungkin! yang logis adalah menyiapkan anak dan siswa kita agar dia punya mental yang tangguh untuk mampu menjauhi keburukan teknologi dan punya mental yang tangguh untuk hanya fokus kepada manfaatnya serta punya mental yang produktif bahkan monetitatif dalam berteknologi.Buku ini menjadi penting bagi pendidik (orang tua dan guru) karena di dalamnya terdapat langkah demi langkah untukmembangun \"mental-mental berteknologi\" tersebut.",
      publishYear: 2025,
      price: {
        normal: 140000,
        discount: 112000
      },
      coverUrl: "img/BT/cover.jpg",
      linkid: "https://gsiofficial.xyz/gsiofficial/9QGJL29",
      linkshopee: "https://shopee.co.id/Seri-Teknologi-Islam-Mental-Belajar-i.1344216734.42801659863",
    },
      {
      id: "book-5",
      judul: "IT DENGAN PROYEK FESTIVAL",
      seri: "Seri Teknologi Islami",
      deskripsi: "Efektivitas pembelajaran IT tidak akan sempurna tanpa jam dan strategi praktik yang baik.Pembelajaran yang disertai dengan praktik lebih efektif dengan persentase keberhasilan yang lebih tinggi (85%) dibandingkan dengan pembelajaran melalui teori saja (55%). Buku ini membahas tentang bagaimana menjalankan strategi pembelajaran berbasis project.Buku ini juga membahas tentang peningkatan kualitas guru agar mampu menciptakan dan mengawal proyek-proyek di mapel IT",
      publishYear: 2025,
      price: {
        normal: 120000,
        discount: 95000
      },
      coverUrl: "img/IT-PF/cover.jpg",
      linkid: "https://gsiofficial.xyz/gsiofficial/ep5AkLv",
      linkshopee: "https://shopee.co.id/Seri-Teknologi-Islami-IT-dengan-Proyek-Festival-i.1344216734.43501664649",
    },
      {
      id: "book-6",
      judul: "IT BERORIENTASI PRODUKTIF",
      seri: "Seri Teknologi Islami",
      deskripsi: "Jaman sudah berubah, portofolio menjadi lebih penting daripada ijazah.Perusahaan zaman sekarang lebih sering bertanya, \"Berapa perangkat lunak yang pernah Anda buat?\", \"Anda sudah terlibat dalam berapa proyek?\" Oleh karena itu, mari kita dorong anak dan siswa kita untuk mencari ide, untuk mengerjakan proyek dan menciptakan atau membuat produk.Buku ini memandu guru dan orangtua untuk menuntun tahap demi tahap agar anak dan siswa kita belajar IT secara produktif.",
      publishYear: 2025,
      price: {
        normal: 135000,
        discount: 108000
      },
      coverUrl: "img/IT-BP/cover.jpg",
      linkid: "https://gsiofficial.xyz/gsiofficial/oPNVqAV",
      linkshopee: "https://shopee.co.id/Seri-Teknologi-Islami-IT-Berorientasi-Produktif-i.1344216734.41351680050",
    },
    {
        id: "book-7",
        judul: "IT BERORIENTASI MONETITATIF",
        seri: "Seri Teknologi Islami",
        deskripsi: "Keahlian teknologi menjadi salah satu kunci utama untuk meraih kesuksesan finansial. Monetisasi harus menjadi target pembelajaran, sehingga pelajar di bidang IT selalu berpikir tentang bagaimana cara menghasilkan pendapatan dari teknologi. Buku ini mengarahkan anak dan siswa kita untuk bercita-cita menjadi seorang technopreneur, yaitu wirausaha berbasis teknologi, dengan cara mencipta dan membuat suatu produk dan berlatih untuk memonetisasinya",
        publishYear: 2025,
        price: {
          normal: 125000,
          discount: 99000
        },
        coverUrl: "img/IT-BM/cover.jpg",
        linkid: "https://gsiofficial.xyz/gsiofficial/xQAKrGZ",
        linkshopee: "https://shopee.co.id/Seri-Teknologi-Islami-IT-Berorientasi-Monetitatif-i.1344216734.43551675445",
      },
    

      // buku lain...
    ]
  };

   // Ambil buku pertama
  const wrapper = document.getElementById('book-swiper-wrapper');

data.books.forEach(book => {
  const slide = document.createElement('div');
  slide.className = 'swiper-slide flex flex-col md:flex-row items-center';

  slide.innerHTML = `
    <div class="md:w-1/2 mb-8 md:mb-0" id="book-info">
      <span class="text-gray-700 font-semibold text-xl">${book.seri}</span>
      <h1 class="text-4xl md:text-5xl font-bold mt-2 mb-4">${book.judul}</h1>
      <p class="hidden md:block text-lg mb-8 text-gray-700">${book.deskripsi}</p>

      <div class="flex flex-wrap gap-4">
        <button
          class="get-btn bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-8 rounded-md transition duration-300"
          data-type="pesan"
          data-judul="${book.judul}"
        >
          Pesan Sekarang - Rp${book.price.discount.toLocaleString('id-ID')}
        </button>
        <button
          class="get-btn bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 px-8 rounded-md transition duration-300"
          data-type="shopee"
          data-judul="${book.judul}"
        >
          Beli di Shopee
        </button>
        <button
          class="get-btn bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-8 rounded-md transition duration-300"
          data-type="detail"
          data-id="${book.id}"
        >
          Detail Buku
        </button>
      </div>

      <div class="mt-8 flex space-x-4 text-blue">
        <span class="flex items-center"><i class="fas fa-calendar mr-2"></i> ${book.publishYear}</span>
        <span class="flex items-center"><i class="fas fa-tag mr-2"></i> ${book.seri}</span>
      </div>
    </div>
    <div class="md:w-1/2 flex justify-center">
      <div class="relative">
        <div class="absolute -inset-4 rounded-full bg-blue-500 opacity-30 blur-lg"></div>
        <img src="${book.coverUrl}" alt="${book.judul}" class="book-cover h-80 md:h-96 relative z-10 shadow-2xl rounded-lg" />
      </div>
    </div>
  `;

  wrapper.appendChild(slide);

  // Handler untuk semua tombol
  const buttons = slide.querySelectorAll(".get-btn");
  buttons.forEach(btn => {
    const type = btn.dataset.type;

    if (type === "pesan") {
      btn.addEventListener("click", () => {
        // Menggunakan linkid untuk tombol pesan
        window.open(book.linkid, "_blank");
      });
    } else if (type === "shopee") {
      btn.addEventListener("click", () => {
        // Menggunakan linkshopee untuk tombol shopee
        window.open(book.linkshopee, "_blank");
      });
    } else if (type === "detail") {
      btn.addEventListener("click", () => {
        // Menggunakan linkshopee untuk tombol detail (tidak diubah)
        window.location.href = `detailbuku.html?id=${book.id}`;
      });
    }
  });
});
  // <button class="bg-transparent border-2 border-white hover:bg-white hover:text-blue-900 text-white font-bold py-3 px-8 rounded-md transition duration-300">
  //           Coba Gratis
  //         </button>
  // Inisialisasi Swiper
  const swiper = new Swiper('.book-swiper', {
    loop: true,
    autoplay: {
      delay: 5000,
      disableOnInteraction: false,
    },
    pagination: {
      el: '.swiper-pagination',
      clickable: true,
    },
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
  });

  
  document.addEventListener('DOMContentLoaded', function() {
  const bookList = document.getElementById("book-list");

  // Populate book slides
  data.books.forEach(book => {
    const slide = document.createElement("div");
    slide.className = "swiper-slide";

    slide.innerHTML = `
      <div class="bg-white p-6 rounded-lg shadow-lg max-w-md mx-auto h-full flex flex-col justify-between">
        <div>
          <h3 class="text-xl font-bold mb-4">${book.judul}</h3>
          <div class="flex items-start gap-6 mb-6">
            <img src="${book.coverUrl}" alt="Cover ${book.judul}" class="w-32 h-auto object-cover rounded">
            <div>
              <p class="text-gray-700 text-sm mb-3">${book.deskripsi}</p>
              <p class="text-sm text-gray-500">Tahun: ${book.publishYear}</p>
            </div>
          </div>
          <div class="mb-6">
            <span class="line-through text-gray-500 text-sm">Rp ${book.price.normal.toLocaleString("id-ID")}</span>
            <span class="text-lg font-bold text-orange-600 ml-2">Rp ${book.price.discount.toLocaleString("id-ID")}</span>
          </div>
        </div>
        <button
          class="order-btn bg-yellow-500 hover:bg-yellow-600 text-orange-900 font-bold py-3 px-4 w-full rounded-md transition duration-300 flex items-center justify-center gap-2"
          data-judul="${book.judul}"
          data-seri="${book.seri}"
        >
          <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 000-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3zM16 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM6.5 18a1.5 1.5 0 100-3 1.5 1.5 0 000 3z" />
          </svg>
          Pesan Sekarang
        </button>
      </div>
    `;

    bookList.appendChild(slide);
  });

  // Add event listeners to all order buttons
  document.querySelectorAll('.order-btn').forEach(button => {
    button.addEventListener("click", () => {
      const judul = button.getAttribute('data-judul');
      const seri = button.getAttribute('data-seri');
      const pesan = `Halo, saya ingin pre-order buku: *${judul}* dari seri "${seri}".`;
      const nomor = "6285161231559";
      const url = `https://wa.me/${nomor}?text=${encodeURIComponent(pesan)}`;
      window.open(url, "_blank");
    });
  });

  // Initialize Swiper
  const swiper = new Swiper(".mySwiper2", {
    slidesPerView: 1,
    spaceBetween: 30,
    loop: true,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    breakpoints: {
      768: {
        slidesPerView: 2
      },
      1024: {
        slidesPerView: 3
      }
    }
  });
});

function flipCard(container) {
  container.classList.toggle('flip');
}

const autoFlipContainer = document.getElementById("autoFlipCard");
          
  // Flip manual saat diklik
  autoFlipContainer.addEventListener("click", () => {
    autoFlipContainer.classList.toggle("flip");
  });

  // Flip otomatis setiap 3 detik
  setInterval(() => {
    autoFlipContainer.classList.toggle("flip");
  }, 3000);

  

  document.addEventListener("DOMContentLoaded", () => {
    // Tracking section aktif saat scroll
    const sections = document.querySelectorAll("section[id]");
    const navLinks = document.querySelectorAll(".nav-link");
    
    function onScroll() {
        // Mendapatkan posisi scroll
        const scrollPosition = window.scrollY + 100;
        
        // Mencari section yang sedang aktif
        let currentSectionId = "";
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            
            if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                currentSectionId = section.getAttribute("id");
            }
        });
        
        // Update class active pada link navigasi
        navLinks.forEach(link => {
            link.classList.remove("active");
            if (link.getAttribute("href") === `#${currentSectionId}`) {
                link.classList.add("active");
            }
        });
    }
    
    // Toggle menu mobile
    const mobileMenuButton = document.getElementById("mobile-menu-button");
    const mobileMenu = document.getElementById("mobile-menu");
    
    mobileMenuButton.addEventListener("click", function() {
        mobileMenu.classList.toggle("show");
        console.log("Menu mobile diklik:", mobileMenu.classList.contains("show"));
    });
    
    // Menutup menu mobile ketika klik link
    const mobileLinks = mobileMenu.querySelectorAll("a");
    mobileLinks.forEach(link => {
        link.addEventListener("click", () => {
            mobileMenu.classList.remove("show");
        });
    });
    
    // Event listeners untuk scroll dan resize
    window.addEventListener("scroll", onScroll);
    window.addEventListener("resize", onScroll);
    
    // Jalankan onScroll saat halaman dimuat
    onScroll();
});